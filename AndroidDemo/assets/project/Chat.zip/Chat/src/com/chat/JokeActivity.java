package com.chat;

/**
 * 笑话精粹界面
 * @author yanhao
 * @version 1.0
 */

public class JokeActivity extends AbsListActivity {

	@Override
	public String getFileName() {
		return "joke.txt";
	}
}