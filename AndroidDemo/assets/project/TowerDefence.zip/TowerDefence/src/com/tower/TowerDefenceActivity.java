package com.tower;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class TowerDefenceActivity extends Activity {
	
	private static final int MENU_start = 1;
	private static final int MENU_next 	= 2;
	private static final int MENU_pause = 3;
	private static final int MENU_exit 	= 4;
	
	private TowerDefenceGame game;
	
	private boolean isPause;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(game = new TowerDefenceGame(this));
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	menu.add(0, MENU_start, 0, getString(R.string.MENU_start));
		menu.add(0, MENU_next,  0, getString(R.string.MENU_next));
		menu.add(0, MENU_pause, 0, getString(R.string.MENU_pause));
		menu.add(0, MENU_exit,  0, getString(R.string.MENU_exit));
    	return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
		case MENU_start:
			game.resetGame();
			break;
		case MENU_next:
			game.nextGame();
			break;
		case MENU_pause:
			game.pause(isPause = !isPause);
			break;
		case MENU_exit:
			finish();
			break;
		}
    	
    	return true;
    }
    
    @Override
    protected void onDestroy() {
    	if (game != null)
    	{
    		game.exit();
    	}
    	
    	super.onDestroy();
    }
}