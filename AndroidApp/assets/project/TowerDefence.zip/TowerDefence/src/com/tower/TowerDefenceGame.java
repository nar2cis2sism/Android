package com.tower;

import static engine.android.game.util.MapDataManager.loadMap;

import engine.android.game.Box;
import engine.android.game.GameCanvas;
import engine.android.game.GameCanvas.GameResource.GameResourceLoader;
import engine.android.game.GameEngine;
import engine.android.game.GameEngine.GameHandler;
import engine.android.game.layer.Area;
import engine.android.game.layer.Label;
import engine.android.game.layer.Sprite;
import engine.android.game.util.GamePath;
import engine.android.game.util.MapDataManager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;

import com.tower.TowerDefenceData.EnemyData;
import com.tower.TowerDefenceData.EnemyData.EnemyImage;
import com.tower.view.Bullet;
import com.tower.view.Enemy;
import com.tower.view.Map;
import com.tower.view.Map.TowerPlaceListener;
import com.tower.view.Tower;
import com.tower.view.TowerListArea;
import com.tower.view.TowerUpgradeMenu;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * 塔防游戏
 * 
 * @author Daimon
 * @since 7/3/2012
 */
public class TowerDefenceGame extends GameCanvas implements
TowerPlaceListener, GameResourceLoader, TowerDefenceConstant {

    TowerDefenceData data;									// 游戏数据

    TowerDefenceEngine engine;								// 游戏引擎

    MapDataManager mdm;										// 地图数据管理器

    GameHandler handler;									// 游戏处理器

    List<Tower> towers;										// 炮塔集合

    List<Enemy> enemies;									// 敌人集合

    List<Bullet> bullets;									// 子弹集合

    Random random = new Random();

    int gameLevel;											// 当前关卡

    int money;												// 游戏金钱

    int enemyEscaped;										// 敌人逃脱数量

    EnemyData enemyData;									// 当前敌人数据

    int enemyLevel;											// 敌人等级

    int enemyHP;											// 敌人血量

    float enemySpeed;										// 敌人移动速度

    int enemyNum;											// 已产生敌人数量

    Area gameBg;											// 游戏背景

    Area gameArea;											// 游戏区域

    Label message;											// 游戏信息

    Map map;												// 游戏地图

    TowerListArea towerListArea;							// 炮塔选择列表区域

    TowerUpgradeMenu towerMenu;                             // 炮塔升级菜单

    public TowerDefenceGame(Context context) {
        super(context);
        init();
    }

    public TowerDefenceGame(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        getSettings()
        .supportAdvancedTouchEvents()
        .supportScreenAutoAdapt(true, FULLSCREEN, screenWidth, screenHeight)
        .showFPS(true);
        
        data = new TowerDefenceData();
        engine = new TowerDefenceEngine();
        mdm = new MapDataManager();
        handler = new GameHandler();

        towers = new Box<Tower>();
        enemies = new Box<Enemy>();
        bullets = new Box<Bullet>();
    }

    @Override
    protected void onCreate() {
        try {
            // 初始化游戏数据
            initData();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        gameBg = new Area(load("map1.jpg", screenWidth, screenHeight));

        map = new Map(gridWidth, gridHeight);
        map.setMapData(mdm.getMap());
        map.setVisibility(INVISIBLE);
        map.setTowerPlaceListener(this);

        towerListArea = new TowerListArea(
                load("tower1.png", gridWidth, gridHeight),
                load("tower2.png", gridWidth, gridHeight),
                load("tower3.png", gridWidth, gridHeight),
                load("tower4.png", gridWidth, gridHeight));
        towerListArea.setTowerSelectListener(map);
        towerListArea.selectTower(0);

        towerMenu = new TowerUpgradeMenu();

        gameArea = new Area(screenWidth, screenHeight);

        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setTextSize(24);

        message = new Label();
        message.setPaint(paint);

        getContentPane().append(gameBg);
        getContentPane().append(gameArea);
        getContentPane().append(message);
        getContentPane().append(map);
        getContentPane().append(towerListArea);
//        getContentPane().append(towerMenu);

        register(engine);

        loadDataByLevle(gameLevel = 1);
    }

    private void initData() throws Exception {
        GameResource.loadResource(this);
        // 加载地图数据
        mdm.add(loadMap(getResources().openRawResource(R.raw.map1)));
        mdm.add(loadMap(getResources().openRawResource(R.raw.map2)));
        mdm.add(loadMap(getResources().openRawResource(R.raw.map3)));
        mdm.add(loadMap(getResources().openRawResource(R.raw.map4)));

        data.init();
    }

    /**
     * 根据游戏关卡加载游戏数据
     * 
     * @param level 关卡等级
     */
    private void loadDataByLevle(int level) {
        mdm.setMap(level - 1);
        map.setMapData(mdm.getMap());

        enemyLevel = 0;
        enemyEscaped = 0;
        enemyNum = 0;
        enemyData = data.loadEnemyData(enemyLevel);
        money = data.getGameMoney(level);

        updateMessage();
    }

    @Override
    public void load(java.util.Map<String, Object> map) {
        // 文本
        map.put("Tower_attack", getResources().getString(R.string.Tower_attack));
        map.put("Tower_speed", getResources().getString(R.string.Tower_speed));
        map.put("Tower_range", getResources().getString(R.string.Tower_range));

        map.put("Enemy_level", getResources().getString(R.string.Enemy_level));
        map.put("Enemy_HP", getResources().getString(R.string.Enemy_HP));
        map.put("Enemy_speed", getResources().getString(R.string.Enemy_speed));
        map.put("Enemy_escaped", getResources().getString(R.string.Enemy_escaped));
        map.put("Game_money", getResources().getString(R.string.Game_money));
    }

    /**
     * 添加炮塔
     * 
     * @param type 炮塔类型
     */
    private void addTower(Sprite tower, int type) {
        Tower t = new Tower(tower.getImage());
        t.setPosition(tower.getX(), tower.getY());
        t.setTowerType(type);
        towers.add(t);
        gameArea.addSprite(t);
    }

    void addEnemy() {
        EnemyImage enemyImage = enemyData.image;
        Enemy e = new Enemy(load(enemyImage.name), enemyImage.tileWidth, enemyImage.tileHeight);
        e.defineReferencePixel(e.getWidth() / 2, e.getHeight());

        GamePath path = data.getEnemyPathByLevel(gameLevel, map, e.getWidth(), e.getHeight());
        if (path != null)
        {
            e.setRefPixelPosition((int) path.getCoordsX(0), (int) path.getCoordsY(0));
        }
        // 设置敌人基本属性
        e.setEnemyData(enemyData);
        // 设置敌人移动路径
        e.setMovePath(path);

        enemies.add(e);
        gameArea.addSprite(e);
        enemyNum++;
    }

    void killEnemy(Enemy enemy) {
        enemies.remove(enemy);
        gameArea.removeSprite(enemy);
        // 爆炸效果
        final Sprite bomb = new Sprite(load("bomb.png"));
        bomb.defineReferencePixel(bomb.getWidth() / 2, bomb.getHeight() / 2)
                .setRefPixelPosition(enemy.getCenterX(), enemy.getCenterY());
        gameArea.addSprite(bomb);
        handler.getHandler().postDelayed(new Runnable() {

            @Override
            public void run() {
                gameArea.removeSprite(bomb);
            }
        }, 100);

        money += enemy.getMoney();
        updateMessage();
    }

    /**
     * 生成子弹
     */
    Bullet generateBullet(Tower tower) {
        Bullet bullet = new Bullet(getBulletImage(tower.getTowerType()));
        bullet.defineReferencePixel(bullet.getWidth() / 2, bullet.getHeight() / 2)
                .setRefPixelPosition(tower.getCenterX(), tower.getCenterY());
        bullet.setTower(tower);
        return bullet;
    }

    private Bitmap getBulletImage(int type) {
        switch (type) {
            case Tower.NORMAL:
                return load("bullet1.png", 32, 10);
            case Tower.STRONG:
                return load("bullet4.png");
            case Tower.MULTIPLE:
                return load("bullet2.png", 32, 10);
            case Tower.SLOW:
                return load("bullet3.png");

            default:
                throw new IllegalArgumentException("Bad Tower");
        }
    }

    @Override
    public boolean onTowerPlaced(Sprite tower) {
        int type = towerListArea.getSelectedIndex();
        int price = data.getTowerPrice(type);
        if (money >= price)
        {
            money -= price;
            addTower(tower, type);
            updateMessage();
            return true;
        }

        return false;
    }

    private void updateMessage() {
        message.setText(getMessage());
        message.moveToBottom(getContentPane().getHeight() - 50);
    }

    private String getMessage() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(GameResource.getText("Enemy_level"), enemyLevel + 1)).append("\n");
        sb.append(enemyData.name).append("\n");
        sb.append(GameResource.getText("Enemy_HP")).append(enemyData.HP).append("\n");
        sb.append(GameResource.getText("Enemy_speed")).append(enemyData.speed).append("\n");
        sb.append(GameResource.getText("Enemy_escaped")).append(enemyEscaped).append("\n");
        sb.append(GameResource.getText("Game_money")).append(money);
        return sb.toString();
    }

    public void resetGame() {
        towers.clear();
        enemies.clear();
        gameArea.clear();

        loadDataByLevle(gameLevel);

        towerListArea.selectTower(0);
        updateTowerListLocation();
    }

    private void updateTowerListLocation() {
        // 更新炮塔选择列表偏移
        switch (gameLevel) {
            case 1:
            case 2:
            case 4:
                towerListArea.setPosition(0, 0);
                break;
            case 3:
                towerListArea.setPosition(215, 0);
                break;
        }
    }

    public void nextGame() {
        if (++gameLevel > mdm.getNum())
        {
            gameLevel = 1;
        }

        resetGame();

        gameBg.setImage(load(String.format("map%d.jpg", gameLevel), screenWidth, screenHeight));
        updateMapLocation();
    }

    private void updateMapLocation() {
        // 更新地图偏移
        switch (gameLevel) {
            case 1:
            case 4:
                map.setPosition(0, 0);
                break;
            case 2:
                map.setPosition(16, 0);
                break;
            case 3:
                map.setPosition(-8, 0);
                break;
        }
    }

    private class TowerDefenceEngine extends GameEngine {
        
        public TowerDefenceEngine() {
            setPeriod(100);
        }

        @Override
        protected void doEngine() {
            for (Enemy e : enemies)
            {
                // 敌人移动
                if (e.isMoving())
                {
                    e.moveByPath();

                    if (e.getHP() <= 0)
                    {
                        killEnemy(e);
                        continue;
                    }

                    if (!e.isBlood())
                    {
                        // 走出了所有塔的攻击范围之后不再显示血条
                        boolean displayHP = false;
                        for (Tower t : towers)
                        {
                            if (t.isInAttackRange(e))
                            {
                                displayHP = true;
                                break;
                            }
                        }

                        if (!displayHP)
                        {
                            // 隐藏血量条
                            e.hideHP();
                        }
                    }
                }
                else
                {
                    enemies.remove(e);
                    gameArea.removeSprite(e);
                    enemyEscaped++;
                    updateMessage();
                }
            }

            for (final Tower t : towers)
            {
                // 炮塔攻击
                if (t.canAttack())
                {
                    // 记录所有进入炮塔攻击范围内的敌人
                    List<Enemy> list = new LinkedList<Enemy>();
                    for (Enemy e : enemies)
                    {
                        if (t.isInAttackRange(e))
                        {
                            list.add(e);
                        }
                    }

                    if (list.isEmpty())
                    {
                        continue;
                    }

                    if (t.getTowerType() == Tower.MULTIPLE)
                    {
                        // 多重箭可以攻击多个敌人
                        list = list.subList(0, Math.min(t.getMulAttackNum(), list.size()));
                    }
                    else
                    {
                        int index = 0;
                        if (t.getTowerType() == Tower.SLOW)
                        {
                            // 减速塔随机攻击一个敌人
                            index = random.nextInt(list.size());
                        }
                        else if (t.getTowerType() == Tower.NORMAL && !t.isSpeeding())
                        {
                            // 普通塔有一定概率加速攻击
                            if (random.nextInt(100) < 5)
                            {
                                t.speed(true);
                                handler.getHandler().postDelayed(new Runnable() {

                                    @Override
                                    public void run() {
                                        t.speed(false);
                                    }
                                }, 2000);
                            }
                        }

                        Enemy e = list.get(index);
                        list.clear();
                        list.add(e);
                    }

                    boolean attack = false;
                    for (Enemy e : list)
                    {
                        if (e.consumeHP() > 0)
                        {
                            Bullet b = generateBullet(t);
                            b.setEnemy(e);
                            bullets.add(b);
                            gameArea.addSprite(b);
                            attack = true;
                        }
                    }

                    if (attack)
                    {
                        t.attack();
                    }
                }
            }

            for (Bullet b : bullets)
            {
                // 子弹移动
                if (b.isMoving())
                {
                    b.move();
                }
                else
                {
                    bullets.remove(b);
                    gameArea.removeSprite(b);

                    final Enemy e = b.getEnemy();
                    final Tower t = b.getTower();
                    if (!enemies.contains(e))
                    {
                        // 敌人已逃脱或者已被消灭
                        continue;
                    }

                    int mul = 1;
                    switch (t.getTowerType()) {
                        case Tower.STRONG:
                            // 多倍攻击
                            int rand = random.nextInt(100);
                            if (rand < 3)
                            {
                                mul = 5;
                            }
                            else if (rand < 9)
                            {
                                mul = 4;
                            }
                            else if (rand < 21)
                            {
                                mul = 3;
                            }
                            else if (rand < 45)
                            {
                                mul = 2;
                            }

                            break;
                        case Tower.MULTIPLE:
                            // 多重攻击
                            if (!e.isBlood() && random.nextInt(100) < 10)
                            {
                                e.blood();
                            }

                            break;
                        case Tower.SLOW:
                            // 减速
                            boolean slow = false;
                            if (t.getAttackInterval() <= Tower.MIN_interval)
                            {
                                if (random.nextInt(100) < 20)
                                {
                                    e.spin();
                                    slow = true;
                                }
                            }
                            else
                            {
                                if (random.nextInt(100) < 5)
                                {
                                    e.spin();
                                }
                                else
                                {
                                    e.slow();
                                }

                                slow = true;
                            }

                            if (slow)
                            {
                                handler.register("Enemy_recoverSlow" + e, new Runnable() {

                                    @Override
                                    public void run() {
                                        e.recoverSlow();
                                    }
                                });
                                handler.postDelayed("Enemy_recoverSlow" + e, 2000);
                            }

                            break;
                    }

                    b.damage(mul);
                    if (e.isPunch())
                    {
                        handler.register("Enemy_endPunch" + e, new Runnable() {

                            @Override
                            public void run() {
                                e.endPunch();
                            }
                        });
                        handler.postDelayed("Enemy_endPunch" + e, 400);
                    }
                    // 敌人血量少于0则消失
                    if (e.getHP() <= 0)
                    {
                        killEnemy(e);
                    }
                }
            }
            // 游戏状态
            if (enemyEscaped >= 30)
            {
                // 游戏结束
                return;
            }

            if (enemyNum < enemyData.num)
            {
                // 继续产生敌人
                if (enemies.isEmpty())
                {
                    addEnemy();
                }
                else
                {
                    Enemy e = enemies.get(enemies.size() - 1);
                    if (e.getY() >= map.getGridHeight() + e.getHeight())
                    {
                        addEnemy();
                    }
                }
            }
            else
            {
                if (enemies.isEmpty())
                {
                    // 当前敌人全部死完或者逃脱的时候才添加下一波敌人
                    if (++enemyLevel >= data.getEnemyMaxLevel())
                    {
                        // 进行下一关
                        nextGame();
                    }
                    else
                    {
                        enemyData = data.loadEnemyData(enemyLevel);
                        enemyNum = 0;
                        updateMessage();
                    }
                }
            }
        }
    }
}