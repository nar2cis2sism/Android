package com.tower.view;

import static engine.android.util.api.RectUtil.setRect;

import engine.android.game.layer.Sprite;
import engine.android.game.util.MapDataManager.MapView;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.tower.view.TowerListArea.TowerSelectListener;

public class Map extends MapView implements TowerSelectListener {

    private int gridWidth, gridHeight;				// 网格大小

    private int rows, cols;							// 行列数

    private int currentRow, currentCol;				// 当前指向行列数

    private Sprite tower;							// 指向炮塔

    private TowerPlaceListener listener;			// 炮塔放置监听器

    public Map(int gridWidth, int gridHeight) {
        this.gridWidth = gridWidth;
        this.gridHeight = gridHeight;
    }

    @Override
    public void setMapData(int[][] mapData) {
        super.setMapData(mapData);
        rows = mapData.length;
        cols = mapData[0].length;
        sizeChanged(gridWidth * cols, gridHeight * rows);
    }

    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }

    public int getGridWidth() {
        return gridWidth;
    }

    public int getGridHeight() {
        return gridHeight;
    }

    @Override
    public void onDraw(Canvas canvas) {
        Paint paint = getPaint();
        paint.setColor(Color.WHITE);
        for (int i = 0; i <= rows; i++)
        {
            canvas.drawLine(
                    getX(), getY() + i * gridHeight,
                    getX() + cols * gridWidth, getY() + i * gridHeight,
                    paint);
        }

        for (int i = 0; i <= cols; i++)
        {
            canvas.drawLine(
                    getX() + i * gridWidth, getY(),
                    getX() + i * gridWidth, getY() + rows * gridHeight,
                    paint);
        }

        super.onDraw(canvas);
        // 绘制指向炮塔
        if (tower != null)
        {
            tower.paint(canvas);
        }
    }

    /**
     * 显示指向炮塔
     */
    private void showTower(int x, int y) {
        if (tower != null)
        {
            getCurrentRowAndCol(x, y);
            tower.setPosition(getX() + currentCol * gridWidth, getY() + currentRow * gridHeight);
        }
    }

    @Override
    protected void drawMap(Canvas canvas, int row, int col, int flag) {
        Paint paint = getPaint();
        // flag:-1表示不可放置炮塔，0表示可以放置炮塔，1表示炮塔已经存在
        switch (flag) {
            case -1:
                paint.setColor(Color.RED);
                paint.setAlpha(80);
                break;
            case 0:
                paint.setColor(Color.GREEN);
                paint.setAlpha(80);
                break;

            default:
                return;
        }

        canvas.drawRect(setRect(null,
                getX() + col * gridWidth, getY() + row * gridHeight,
                gridWidth, gridHeight),
                paint);
    }

    @Override
    protected boolean mousePressed(int x, int y) {
        showTower(x, y);

        int flag = getFlag(currentRow, currentCol);
        if (flag == 1)
        {
            return false;
        }

        setVisibility(VISIBLE);
        return true;
    }

    @Override
    protected boolean mouseDragged(int x, int y) {
        showTower(x, y);

        int flag = getFlag(currentRow, currentCol);
        if (flag == 1)
        {
            setVisibility(INVISIBLE);
        }
        else
        {
            setVisibility(VISIBLE);
        }

        return false;
    }

    @Override
    protected boolean mouseReleased(int x, int y) {
        setVisibility(INVISIBLE);

        int flag = getFlag(currentRow, currentCol);
        if (flag == 0)
        {
            // 放置炮塔
            if (listener != null)
            {
                if (listener.onTowerPlaced(tower))
                {
                    setFlag(currentRow, currentCol, 1);
                }
            }
        }

        return false;
    }

    private void getCurrentRowAndCol(int x, int y) {
        currentRow = (y - getY()) / gridHeight;
        currentCol = (x - getX()) / gridWidth;
        if (currentRow < 0)
        {
            currentRow = 0;
        }
        else if (currentRow >= rows)
        {
            currentRow = rows - 1;
        }

        if (currentCol < 0)
        {
            currentCol = 0;
        }
        else if (currentCol >= cols)
        {
            currentCol = cols - 1;
        }
    }

    @Override
    public void onTowerSelected(Sprite tower) {
        if (this.tower == null)
        {
            this.tower = new Sprite(tower.getImage());
        }
        else
        {
            this.tower.setImage(tower.getImage());
        }
    }

    public void setTowerPlaceListener(TowerPlaceListener listener) {
        this.listener = listener;
    }

    public interface TowerPlaceListener {

        /**
         * 炮塔放置
         * 
         * @return 是否能建造炮塔（可能金钱不够）
         */
        boolean onTowerPlaced(Sprite tower);
    }
}