package com.chat;

/**
 * 故事集锦界面
 * @author yanhao
 * @version 1.0
 */

public class StoryActivity extends AbsListActivity {

	@Override
	public String getFileName() {
		return "story.txt";
	}
} 