package com.tower.view;

import static engine.android.util.api.RectUtil.setRect;

import engine.android.game.GameCanvas.GameResource;
import engine.android.game.layer.FrameSprite;
import engine.android.game.layer.Label;
import engine.android.game.layer.Sprite;
import engine.android.game.util.GamePath;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.tower.TowerDefenceData.EnemyData;

public class Enemy extends FrameSprite {

    /***** 移动方向 *****/
    public static final int NONE    = 0;	    // 静止不动
    public static final int LEFT    = 1;	    // 向左移动
    public static final int UP      = 2;	    // 向上移动
    public static final int RIGHT   = 3;	    // 向右移动
    public static final int DOWN    = 4;	    // 向下移动

    private int direction;						// 移动方向

    private GamePath movePath;					// 移动路径
    private int moveIndex;						// 移动路径索引

    private boolean isMoving;					// 移动开关

    private int originHP;						// 原始血量
    private int HP;								// 生命值
    private boolean displayHP;					// 血量显示开关
    private int consumeHP;						// 预支血量

    private int speed;							// 移动速度
    private int SPEED;							// 记录初始移动速度，可能被减速

    private int money;							// 杀死敌人获得的金钱

    private boolean isBlood;					// 流血状态
    private int bloodHP;						// 流血计量

    private boolean isSlow;						// 减速状态

    private Sprite stateSprite;					// 状态绘制精灵

    private boolean isPunch;					// 重击状态
    private int punchDamage;					// 重击伤害
    private Label punchLabel;					// 重击绘制文本

    public Enemy(Bitmap image, int frameWidth, int frameHeight) {
        super(image, frameWidth, frameHeight);

        stateSprite = new Sprite(image);

        Paint paint = new Paint();
        paint.setColor(Color.RED);
        paint.setTextSize(20);

        punchLabel = new Label();
        punchLabel.setPaint(paint);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (displayHP && HP > 0)
        {
            int w = getWidth();
            int h = 5;
            int left = getX();
            int top = getY();

            Paint paint = getPaint();
            paint.setColor(Color.YELLOW);
            paint.setAlpha(50);
            canvas.drawRect(setRect(null, left, top, w, h), paint);

            paint.setColor(Color.GREEN);
            canvas.drawRect(setRect(null, left, top, w * HP / originHP, h), paint);

            if (isPunch)
            {
                punchLabel.setText("-" + punchDamage);
                punchLabel.moveToCenterX(getRefPixelX()).moveToBottom(top);
                punchLabel.paint(canvas);
            }
        }

        if (isSlow)
        {
            if (speed == 0)
            {
                stateSprite.setImage(GameResource.getGame().load("spin.png", 24, 24));
                stateSprite.moveToCenterX(getRefPixelX()).moveToBottom(getY());
            }
            else
            {
                stateSprite.setImage(GameResource.getGame().load("slow.png", 30, 27));
                stateSprite.moveToCenterX(getRefPixelX()).moveToBottom(getY());
            }

            stateSprite.paint(canvas);
        }
        else if (isBlood)
        {
            stateSprite.setImage(GameResource.getGame().load("blood.png", 32, 32));
            stateSprite.moveToCenterX(getRefPixelX()).moveToBottom(getY());
            stateSprite.paint(canvas);
        }
    }

    public void setEnemyData(EnemyData enemyData) {
        originHP = HP = enemyData.HP;
        speed = enemyData.speed;
        money = enemyData.money;
    }

    public void setMovePath(GamePath movePath) {
        this.movePath = movePath;
        moveIndex = 0;
        isMoving = true;
    }

    /**
     * 根据路径移动
     */
    public void moveByPath() {
        if (movePath == null)
        {
            throw new NullPointerException("please set move path");
        }

        if (!isMoving)
        {
            return;
        }
        // 节点坐标
        float x = movePath.getCoordsX(moveIndex);
        float y = movePath.getCoordsY(moveIndex);
        // 获取移动方向
        int direction = NONE;
        if (x > getRefPixelX())
        {
            direction = RIGHT;
        }
        else if (x < getRefPixelX())
        {
            direction = LEFT;
        }
        else if (y < getRefPixelY())
        {
            direction = UP;
        }
        else if (y > getRefPixelY())
        {
            direction = DOWN;
        }

        if (direction != this.direction)
        {
            // 切换移动动画图片
            switch (this.direction = direction) {
                case LEFT:
                    setFrameSequence(new int[] { 4, 5, 6, 7 });
                    break;
                case RIGHT:
                    setFrameSequence(new int[] { 8, 9, 10, 11 });
                    break;
                case UP:
                    setFrameSequence(new int[] { 12, 13, 14, 15 });
                    break;
                case DOWN:
                    setFrameSequence(new int[] { 0, 1, 2, 3 });
            }
        }

        switch (direction) {
            case LEFT:
                if (getRefPixelX() - speed < x)
                {
                    setRefPixelPosition((int) x, getRefPixelY());
                }
                else
                {
                    move(-speed, 0);
                }

                break;
            case RIGHT:
                if (getRefPixelX() + speed > x)
                {
                    setRefPixelPosition((int) x, getRefPixelY());
                }
                else
                {
                    move(speed, 0);
                }

                break;
            case UP:
                if (getRefPixelY() - speed < y)
                {
                    setRefPixelPosition(getRefPixelX(), (int) y);
                }
                else
                {
                    move(0, -speed);
                }

                break;
            case DOWN:
                if (getRefPixelY() + speed > y)
                {
                    setRefPixelPosition(getRefPixelX(), (int) y);
                }
                else
                {
                    move(0, speed);
                }

                break;
        }

        if (isBlood)
        {
            HP--;
            if (--bloodHP <= 0)
            {
                isBlood = false;
            }
        }

        if (getRefPixelX() == x && getRefPixelY() == y)
        {
            // 到达当前节点
            if (++moveIndex >= movePath.getSize())
            {
                // 路径已走完
                isMoving = false;
            }
        }

        nextFrame();
    }

    public boolean isMoving() {
        return isMoving;
    }

    public void consumeHP(int consumeHP) {
        this.consumeHP += consumeHP;
    }

    public int consumeHP() {
        return HP - consumeHP;
    }

    /**
     * 被子弹攻击，血量减少
     * 
     * @param attack 攻击力
     * @param mul 多倍伤害
     */
    public void isAttack(int attack, int mul) {
        int damage = attack * mul;
        HP -= damage;
        consumeHP -= attack;
        displayHP = true;
        if (mul > 1)
        {
            // 重击
            isPunch = true;
            punchDamage = damage;
        }
    }

    public int getHP() {
        return HP;
    }

    public int getMoney() {
        return money;
    }

    public void hideHP() {
        // 需满足条件：无子弹追踪
        if (consumeHP <= 0)
        {
            displayHP = false;
        }
    }

    /********** 特效处理 **********/

    /**
     * 流血
     */
    public void blood() {
        isBlood = true;
        bloodHP = 10;
    }

    public boolean isBlood() {
        return isBlood;
    }

    /**
     * 减速
     */
    public void slow() {
        if (!isSlow)
        {
            isSlow = true;
            SPEED = speed;
            speed /= 2;
        }
    }

    /**
     * 眩晕
     */
    public void spin() {
        if (!isSlow)
        {
            isSlow = true;
            SPEED = speed;
            speed = 0;
        }
    }

    public void recoverSlow() {
        isSlow = false;
        speed = SPEED;
    }

    public boolean isSlow() {
        return isSlow;
    }

    /**
     * 重击
     */
    public void endPunch() {
        isPunch = false;
    }

    public boolean isPunch() {
        return isPunch;
    }
}