package com.tower.view;

import static engine.android.util.api.RectUtil.setRect;

import engine.android.game.layer.Label;
import engine.android.game.layer.Sprite;
import engine.android.game.util.GameMenu;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;

public class TowerUpgradeMenu extends GameMenu {

    private Paint selectedPaint;

    public TowerUpgradeMenu() {
        super(0, 0);

        String[] menuItems = { "攻击强度", "攻击范围", "攻击速度", "取消菜单" };

        Paint paint = new Paint();
        paint.setTextSize(24);
        paint.setColor(Color.GREEN);

        int x = 10;
        int y = 10;
        int h = x;
        int v = y;
        // 攻击强度
        Label label0 = new Label(menuItems[0]);
        label0.setPaint(paint);
        label0.setPosition(x, y);
        addSprite(label0);
        // 攻击范围
        Label label1 = new Label(menuItems[1]);
        label1.setPaint(paint);
        label1.setPosition(label0.getX() + label0.getWidth() + h, y);
        addSprite(label1);
        // 攻击速度
        Label label2 = new Label(menuItems[2]);
        label2.setPaint(paint);
        label2.setPosition(x, label0.getY() + label0.getHeight() + v);
        addSprite(label2);
        // 取消菜单
        Label label3 = new Label(menuItems[3]);
        label3.setPaint(paint);
        label3.setPosition(label1.getX(), label2.getY());
        addSprite(label3);

        sizeChanged(label3.getX() + label3.getWidth() + x, label3.getY() + label3.getHeight() + y);

        selectedPaint = new Paint();
        selectedPaint.setColor(Color.RED);
        selectedPaint.setAlpha(80);
        selectedPaint.setStyle(Style.STROKE);

        setBackground(Color.argb(80, 0, 0, 0));
    }

    @Override
    public void drawMenuItem(Canvas canvas, Sprite menuItem, boolean selected) {
        menuItem.paint(canvas);
        if (selected)
        {
            canvas.drawRect(setRect(null,
                    menuItem.getX(),
                    menuItem.getY(),
                    menuItem.getWidth(),
                    menuItem.getHeight()),
                    selectedPaint);
        }
    }
}