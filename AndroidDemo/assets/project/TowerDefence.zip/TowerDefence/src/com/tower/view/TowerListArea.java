package com.tower.view;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import engine.game.Area;
import engine.game.Sprite;
import engine.game.GameCanvas.TouchEvent;

public class TowerListArea extends Area {
	
	private static final int PaddingTop 	= 10;		//上下间距
	private static final int PaddingBottom 	= 10;
	
	private Paint backgroundPaint;						//背景绘制
	
	private int selectedIndex;							//选择边框
	private Sprite selectedTower;
	private Paint selectedPaint;
	
	private TowerSelectListener listener;				//炮塔选择监听器
	
	private boolean seleteMode;							//选择模式
	private boolean dragMode;							//拖曳模式
	private int dragX,dragY;

	public TowerListArea(Bitmap... tower) {
		super(tower == null || tower.length == 0 ? 0 : tower[0].getWidth(), 
			  tower == null || tower.length == 0 ? 0 : (PaddingTop + PaddingBottom) + 
					  tower[0].getHeight() * tower.length);
		
		if (tower != null && tower.length > 0)
		{
			int y = PaddingTop;
			for (Bitmap image : tower)
			{
				Sprite s = new Sprite(image);
				s.setPosition(0, y);
				addSprite(s);
				
				y += s.getHeight();
			}
			
			backgroundPaint = new Paint();
			backgroundPaint.setColor(Color.BLACK);
			backgroundPaint.setAlpha(80);
			
			selectedPaint = new Paint();
			selectedPaint.setColor(Color.RED);
			selectedPaint.setAlpha(80);
			selectedPaint.setStyle(Style.STROKE);
		}
	}
	
	@Override
	public void onDraw(Canvas canvas) {
		canvas.drawRect(setRect(null, 
				getX(), getY(), getWidth(), getHeight()), 
				backgroundPaint);
		
		super.onDraw(canvas);
		
		canvas.drawRect(setRect(null, 
				getX(), getY() + PaddingTop + selectedIndex * selectedTower.getHeight(), 
				getWidth(), selectedTower.getHeight()), 
				selectedPaint);
	}
	
	@Override
	protected boolean mousePressed(int x, int y) {
		if (collidesWith(x, y, false))
		{
			seleteMode = true;
			return true;
		}
		
		return false;
	}
	
	@Override
	protected boolean mouseDragged(int x, int y) {
		if (seleteMode)
		{
			selectTower(x, y);
			return true;
		}
		
		if (dragMode)
		{
			move(x - dragX, y - dragY);
			dragX = x;
			dragY = y;
			return true;
		}
		
		return false;
	}
	
	@Override
	protected boolean mouseReleased(int x, int y) {
		if (seleteMode)
		{
			selectTower(x, y);
			seleteMode = false;
			return true;
		}
		
		if (dragMode)
		{
			dragMode = false;
			return true;
		}
		
		return false;
	}
	
	@Override
	protected boolean onAdvancedTouchEvent(TouchEvent event) {
		int x = (int) event.getTriggerX();
		int y = (int) event.getTriggerY();
		switch (event.getAction()) {
		case ACTION_LONG_PRESS:
			if (collidesWith(x, y, false))
			{
				seleteMode = false;
				dragMode = true;
				dragX = x;
				dragY = y;
				move(2, 2);
				return true;
			}
		}
		
		return false;
	}
	
	private void selectTower(int x, int y)
	{
		for (int i = 0, size = getSpriteNum(); i < size; i++)
		{
			Sprite s = getSpriteByIndex(i);
			if (s.collidesWith(x, y, false) && i != selectedIndex)
			{
				selectedIndex = i;
				selectTower(s);
			}
		}
	}
	
	/**
	 * 选择炮塔
	 * @param index
	 */
	
	public void selectTower(int index)
	{
		if (index < 0 || index >= getSpriteNum())
		{
			throw new IndexOutOfBoundsException();
		}
		
		selectTower(getSpriteByIndex(selectedIndex = index));
	}
	
	private void selectTower(Sprite tower)
	{
		selectedTower = tower;
		if (listener != null)
		{
			listener.onTowerSelected(selectedTower);
		}
	}
	
	public int getSelectedIndex() {
		return selectedIndex;
	}

	public void setTowerSelectListener(TowerSelectListener listener)
	{
		this.listener = listener;
	}
	
	public static interface TowerSelectListener {
		
		/**
		 * 炮塔选择
		 */
		
		public void onTowerSelected(Sprite tower);
	}
}