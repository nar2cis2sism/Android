package com.tower.view;

import static engine.android.util.api.MathUtil.isOutOfRange;

import engine.android.game.layer.Sprite;
import engine.android.util.image.ImageUtil;

import android.graphics.Bitmap;

public class Bullet extends Sprite {

    private Tower tower;								// 每个子弹属于一个炮塔

    private Enemy enemy;								// 每个子弹攻击一个敌人

    private int damage;									// 子弹的破坏力

    private Bitmap origin;								// 原始图片，用于旋转

    private boolean isMoving;							// 移动开关

    private int ox, oy;									// 记录子弹原始坐标

    public Bullet(Bitmap image) {
        super(image);
        origin = image;
    }

    public void setEnemy(Enemy enemy) {
        (this.enemy = enemy).consumeHP(damage);
        ox = getRefPixelX();
        oy = getRefPixelY();
        isMoving = true;
    }

    public void setTower(Tower tower) {
        damage = (this.tower = tower).getAttack();
    }

    private void rotateImage(int enemyX, int enemyY) {
        // 计算子弹和敌人之间的角度，以便旋转图片
        double angle = Math.toDegrees(Math.atan2(enemyY - getRefPixelY(), enemyX - getRefPixelX()));
        setImage(ImageUtil.rotate(origin, (float) angle));
    }

    /**
     * 移动子弹，自动追踪敌人
     */
    public void move() {
        if (enemy == null)
        {
            throw new NullPointerException("no enemy target");
        }

        if (!isMoving)
        {
            return;
        }
        // 敌人位置
        int enemyX = enemy.getCenterX();
        int enemyY = enemy.getCenterY();

        int dx = (enemyX - ox) / 3;
        int dy = (enemyY - oy) / 3;
        if (isOutOfRange(getRefPixelX(), enemyX, dx) ||  isOutOfRange(getRefPixelY(), enemyY, dy))
        {
            setRefPixelPosition(enemyX, enemyY);
            // 击中敌人
            isMoving = false;
        }
        else
        {
            rotateImage(enemyX, enemyY);
            move(dx, dy);
        }
    }

    public boolean isMoving() {
        return isMoving;
    }

    public Enemy getEnemy() {
        return enemy;
    }

    public Tower getTower() {
        return tower;
    }

    /**
     * @param mul 伤害加倍
     */
    public void damage(int mul) {
        enemy.isAttack(damage, mul);
    }
}