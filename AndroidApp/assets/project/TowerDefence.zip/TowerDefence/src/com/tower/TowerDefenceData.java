package com.tower;

import engine.android.game.util.GamePath;

import com.tower.TowerDefenceData.EnemyData.EnemyImage;
import com.tower.view.Map;
import com.tower.view.Tower;

import java.util.Random;

public class TowerDefenceData {

    private EnemyData[] enemyDatas;

    public static class EnemyData {

        public final int id;							// 唯一标识

        public final EnemyImage image;					// 图片

        public final String name;						// 名称

        public final int HP;							// 生命值

        public final int speed;							// 移动速度

        public final int money;							// 杀死敌人获得的金钱

        public final int num;							// 数量

        public EnemyData(int id, EnemyImage image, String name, int HP, int speed, int money, int num) {
            this.id = id;
            this.image = image;
            this.name = name;
            this.HP = HP;
            this.speed = speed;
            this.money = money;
            this.num = num;
        }

        public static class EnemyImage {

            public final String name;					// 图片名称

            public final int tileWidth, tileHeight;		// 图片砖块大小

            public EnemyImage(String name, int tileWidth, int tileHeight) {
                this.name = name;
                this.tileWidth = tileWidth;
                this.tileHeight = tileHeight;
            }
        }
    }

    public void init() {
		int id = 1;
		enemyDatas = new EnemyData[] {
				new EnemyData(id++, new EnemyImage("enemy10.png", 39, 43), 	"地精男1号",		20,   2, 1,  25),
				new EnemyData(id++, new EnemyImage("enemy11.png", 39, 43), 	"地精男2号",		30,   2, 1,  30),
				new EnemyData(id++, new EnemyImage("enemy12.png", 39, 43), 	"地精男3号",		40,   3, 2,  20),
				new EnemyData(id++, new EnemyImage("enemy1.png",  40, 55), 	"食尸鬼",		60,   3, 2,  20),
				new EnemyData(id++, new EnemyImage("enemy5.png",  32, 48), 	"女拳师",		80,   3, 2,  20),
				new EnemyData(id++, new EnemyImage("enemy3.png",  32, 48), 	"女神官",		60,   4, 3,  20),
				new EnemyData(id++, new EnemyImage("enemy.png",   32, 48),  "女剑士",		100,  3, 3,  20),
				new EnemyData(id++, new EnemyImage("enemy6.png",  32, 48),  "男剑士",		120,  4, 4,  30),
				new EnemyData(id++, new EnemyImage("enemy21.png", 32, 48), 	"疾风忍者",		100,  7, 7,  20),
				new EnemyData(id++, new EnemyImage("enemy20.png", 40, 54), 	"大家叫我MT",	1000, 1, 10, 20),
				new EnemyData(id++, new EnemyImage("enemy9.png",  32, 48),  "穆",			200,  4, 3,  15),
				new EnemyData(id++, new EnemyImage("enemy2.png",  32, 48),  "加隆",			500,  2, 5,  20),
				new EnemyData(id++, new EnemyImage("enemy15.png", 32, 48),  "沙加",			275,  4, 4,  20),
				new EnemyData(id++, new EnemyImage("enemy16.png", 32, 48),  "史昂",			400,  3, 5,  20),
				new EnemyData(id++, new EnemyImage("enemy17.png", 32, 48),  "米罗",			450,  4, 6,  20),
				new EnemyData(id++, new EnemyImage("enemy18.png", 32, 48), 	"卡妙",			500,  4, 7,  20),
				new EnemyData(id++, new EnemyImage("enemy22.png", 32, 48), 	"盗贼",			300,  6, 10, 20),
				new EnemyData(id++, new EnemyImage("enemy19.png", 32, 48), 	"阿布罗迪",		600,  4, 10, 20),
				new EnemyData(id++, new EnemyImage("enemy23.png", 32, 48), 	"修罗",			1200, 2, 12, 20),
				new EnemyData(id++, new EnemyImage("enemy7.png",  32, 48),  "Boss",			5000, 5, 20,  1),
		};
    }

    /**
     * 加载敌人数据
     */
    public EnemyData loadEnemyData(int index) {
        if (index < 0 || index >= enemyDatas.length)
        {
            throw new ArrayIndexOutOfBoundsException();
        }

        return enemyDatas[index];
    }

    /**
     * 返回敌人最高等级
     */
    public int getEnemyMaxLevel() {
        return enemyDatas.length;
    }

    /**
     * 根据游戏级别获取敌人移动路径<br>
     * 水平方向取中心，垂直方向取底部
     */
    public GamePath getEnemyPathByLevel(int level, Map map, int enemyWidth, int enemyHeight) {
        GamePath path = null;
        switch (level) {
            case 1:
                // 随机三个路径
                int index = new Random().nextInt(3);
                int startX = 219;
                int startY = enemyHeight;
                switch (index) {
                    case 0:
                        path = new GamePath(2)
                        .to(startX, startY)
                        .to(startX, 800);
                        break;
                    case 1:
                        path = new GamePath(6)
                        .to(startX, startY)
                        .to(startX, map.getGridHeight() + enemyHeight)
                        .to(1.5f * map.getGridWidth(), map.getGridHeight() + enemyHeight)
                        .to(1.5f * map.getGridWidth(), (map.getRows() - 1) * map.getGridHeight() + enemyHeight)
                        .to(startX, (map.getRows() - 1) * map.getGridHeight() + enemyHeight)
                        .to(startX, 800);
                        break;
                    case 2:
                        path = new GamePath(6)
                        .to(startX, startY)
                        .to(startX, map.getGridHeight() + enemyHeight)
                        .to((map.getCols() - 1.5f) * map.getGridWidth(), map.getGridHeight() + enemyHeight)
                        .to((map.getCols() - 1.5f) * map.getGridWidth(), (map.getRows() - 1) * map.getGridHeight() + enemyHeight)
                        .to(startX, (map.getRows() - 1) * map.getGridHeight() + enemyHeight)
                        .to(startX, 800);
                        break;

                    default:
                        throw new RuntimeException("It won't happen");
                }

                break;
            case 2:
                startX = 354;
                startY = enemyHeight;
                path = new GamePath(13)
                       .to(startX, startY)
                       .to(startX, 175)
                       .to(169, 175)
                       .to(169, 300 + enemyHeight)
                       .to(419, 300 + enemyHeight)
                       .to(419, 535)
                       .to(284, 535)
                       .to(284, 460)
                       .to(167, 460)
                       .to(167, 612)
                       .to(136, 612)
                       .to(136, 715)
                       .to(499, 715);
                break;
            case 3:
                startX = 39;
                startY = enemyHeight;
                path = new GamePath(7)
                .to(startX, startY)
                .to(startX, 195)
                .to(74, 320)
                .to(104, 515)
                .to(139, 635)
                .to(351, 480 + enemyHeight)
                .to(427, 200 + enemyHeight);
                break;
            case 4:
                startX = 134;
                startY = enemyHeight;
                path = new GamePath(7)
                .to(startX, startY)
                .to(startX, 195)
                .to(199, 480)
                .to(144, 315 + enemyHeight)
                .to(46, 630)
                .to(313, 470 + enemyHeight)
                .to(439, 470 + enemyHeight);
                break;
        }

        return path;
    }

    /**
     * 获取炮塔制造价格
     * 
     * @param type 炮塔类型
     */
    public int getTowerPrice(int type) {
        switch (type) {
            case Tower.NORMAL:
                return 10;
            case Tower.STRONG:
                return 25;
            case Tower.MULTIPLE:
                return 15;
            case Tower.SLOW:
                return 20;

            default:
                throw new IllegalArgumentException();
        }
    }

    /**
     * 获取各关卡的游戏金钱
     * 
     * @param gameLevel 关卡等级
     */
    public int getGameMoney(int gameLevel) {
        switch (gameLevel) {
            case 1:
                return 40;
            case 2:
            case 3:
            case 4:
                return 25;

            default:
                throw new IllegalArgumentException();
        }
    }
}

/**
 * 游戏常量
 */
interface TowerDefenceConstant {

    /***** 屏幕大小 *****/
    int screenWidth     = 480;
    int screenHeight    = 800;

    /***** 网格大小 *****/
    int gridWidth       = 64;
    int gridHeight      = 64;
}