package com.tower.view;

import engine.android.game.GameCanvas.GameResource;
import engine.android.game.layer.Label;
import engine.android.game.layer.Sprite;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Tower extends Sprite {
    
    public static final long MIN_interval = 400;       // 最小攻击间隔

    private Paint rangePaint;
    private boolean isPaintRange;

    /***** 炮塔类型 *****/
    public static final int NORMAL      = 0;    // 普通
    public static final int MULTIPLE    = 1;    // 多重攻击
    public static final int SLOW        = 2;    // 减速
    public static final int STRONG      = 3;    // 多倍攻击

    private int type;							// 炮塔类型，用于区分特效
    private Label message;                      // 炮塔信息

    private int attack;							// 攻击力
    private float range;						// 攻击范围

    private long interval_origin;				// 原始攻击间隔
    private long interval;						// 攻击间隔

    private long lastAttackTime;				// 上次攻击时间

    /***** 炮塔特效 *****/
    private boolean isSpeeding;					// 加速攻击
    private int mulAttackNum;					// 多重箭数量

    public Tower(Bitmap image) {
        super(image);

        rangePaint = new Paint();
        rangePaint.setColor(Color.RED);
        rangePaint.setAlpha(50);

        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setTextSize(24);

        message = new Label();
        message.setPaint(paint);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // 绘制攻击范围
        if (isPaintRange)
        {
            canvas.drawCircle(getCenterX(), getCenterY(), range, rangePaint);
            message.paint(canvas);
        }
    }

    private void updateMessage() {
        message.setText(getMessage());
        message.moveToRight(GameResource.getGame().getContentPane().getWidth());
        message.moveToBottom(GameResource.getGame().getContentPane().getHeight() - 75);
    }

    private String getMessage() {
        StringBuilder sb = new StringBuilder();
        sb.append(GameResource.getText("Tower_attack")).append(attack).append("\n");
        sb.append(GameResource.getText("Tower_speed")).append(interval).append("\n");
        sb.append(GameResource.getText("Tower_range")).append(range);
        return sb.toString();
    }

    @Override
    protected boolean mousePressed(int x, int y) {
        if (collidesWith(x, y, false) && !isPaintRange)
        {
            isPaintRange = true;
            return true;
        }

        return super.mousePressed(x, y);
    }

    @Override
    protected boolean mouseDragged(int x, int y) {
        boolean collides = collidesWith(x, y, false);
        if (collides && !isPaintRange)
        {
            isPaintRange = true;
            return true;
        }
        else if (!collides && isPaintRange)
        {
            isPaintRange = false;
        }

        return super.mouseDragged(x, y);
    }

    @Override
    protected boolean mouseReleased(int x, int y) {
        isPaintRange = false;
        return super.mouseReleased(x, y);
    }

    /**
     * 设置炮塔类型
     */
    public void setTowerType(int type) {
        switch (this.type = type) {
            case NORMAL:
                attack = 5;
                setAttackRange(110);
                interval = 800;
                break;
            case STRONG:
                attack = 12;
                setAttackRange(120);
                interval = 1500;
                break;
            case MULTIPLE:
                attack = 3;
                setAttackRange(100);
                interval = 1100;
                break;
            case SLOW:
                attack = 2;
                setAttackRange(100);
                interval = 1000;
                break;

            default:
                throw new IllegalArgumentException();
        }

        updateMessage();
    }

    public void setAttackRange(float range) {
        this.range = range;
        // 多重箭的时候根据攻击范围增加箭的个数
        if (type == MULTIPLE)
        {
            if (range >= 145)
            {
                mulAttackNum = 6;
            }
            else if (range >= 130)
            {
                mulAttackNum = 5;
            }
            else if (range >= 115)
            {
                mulAttackNum = 4;
            }
            else
            {
                mulAttackNum = 3;
            }
        }
    }

    public int getMulAttackNum() {
        return mulAttackNum;
    }

    public int getTowerType() {
        return type;
    }

    public int getAttack() {
        return attack;
    }

    public long getAttackInterval() {
        return interval;
    }

    /**
     * 判断敌人是否在攻击范围内
     */
    public boolean isInAttackRange(Enemy enemy) {
        return Math.sqrt(Math.pow(getCenterX() - enemy.getCenterX(), 2)
                       + Math.pow(getCenterY() - enemy.getCenterY(), 2)) <= range;
    }

    /**
     * 攻击间隔时间到才能攻击
     */
    public boolean canAttack() {
        if ((lastAttackTime == 0 || System.currentTimeMillis() - lastAttackTime >= interval))
        {
            return true;
        }

        return false;
    }

    /**
     * 发动攻击
     */
    public void attack() {
        lastAttackTime = System.currentTimeMillis();
    }

    /**
     * 快速攻击
     * 
     * @param speed 加速开关
     */
    public void speed(boolean speed) {
        if (isSpeeding = speed)
        {
            interval_origin = interval;
            interval /= 2;
        }
        else
        {
            interval = interval_origin;
        }
    }

    public boolean isSpeeding() {
        return isSpeeding;
    }
}