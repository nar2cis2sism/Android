package com.chat;

/**
 * 星座物语界面
 * @author yanhao
 * @version 1.0
 */

public class WordsActivity extends AbsListActivity {

	@Override
	public String getFileName() {
		return "words.txt";
	}
}