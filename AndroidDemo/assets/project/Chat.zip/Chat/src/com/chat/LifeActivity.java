package com.chat;

/**
 * 生活百科界面
 * @author yanhao
 * @version 1.0
 */

public class LifeActivity extends AbsListActivity {

	@Override
	public String getFileName() {
		return "life.txt";
	}
}