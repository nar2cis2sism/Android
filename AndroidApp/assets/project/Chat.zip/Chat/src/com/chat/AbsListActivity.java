package com.chat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;

import android.app.ListActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ScrollView;

/**
 * 共用列表界面
 * @author yanhao
 * @version 1.0
 */

public abstract class AbsListActivity extends ListActivity implements OnItemClickListener {
	
	BufferedReader br;
	
	Map<String, String> map;
	
	ListView lv;
	ScrollView sv;
	MyTextView tv;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.abs_list_activity);
        
        lv = getListView();
        sv = (ScrollView) findViewById(R.id.sv);
        tv = (MyTextView) findViewById(R.id.tv);
        
        try {
			br = new BufferedReader(new InputStreamReader(getAssets().open(getFileName()), "GBK"));
			map = new LinkedHashMap<String, String>();
			
			String str;
			while ((str = br.readLine()) != null)
			{
				str = str.trim();
				if (str.startsWith("[start]"))
				{
					String title = str.substring("[start]".length());
					StringBuilder sb = new StringBuilder();
					while ((str = br.readLine()) != null)
					{
						str = str.trim();
						if (str.startsWith("[end]"))
						{
							if (sb.length() > 0)
							{
								sb.deleteCharAt(sb.length() - 1);
							}
							
							map.put(title, sb.toString());
							break;
						}
						
						sb.append(str);
						sb.append("\n");
					}
				}
			}
			
			ArrayAdapter<String> adapter = 
				new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, map.keySet().toArray(new String[0]));
			setListAdapter(adapter);
			lv.setOnItemClickListener(this);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Override
    public void onBackPressed() {
    	if (sv.getVisibility() == View.VISIBLE)
    	{
    		sv.setVisibility(View.GONE);
    		lv.setVisibility(View.VISIBLE);
    		tv.setText(null);
    	}
    	else
    	{
    		super.onBackPressed();
    	}
    }

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		lv.setVisibility(View.GONE);
		sv.setVisibility(View.VISIBLE);
		sv.scrollTo(0, 0);
		
		String content = map.get(parent.getItemAtPosition(position));
		if (!TextUtils.isEmpty(content))
		{
			tv.setText(content);
		}
	}
	
	public abstract String getFileName();
}