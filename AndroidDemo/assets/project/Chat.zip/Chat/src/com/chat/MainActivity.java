package com.chat;

import java.util.Timer;
import java.util.TimerTask;

import android.app.ActivityGroup;
import android.app.LocalActivityManager;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

/**
 * 主界面
 * @author yanhao
 * @version 1.0
 */

public class MainActivity extends ActivityGroup {
	
	LocalActivityManager lam;
	
	FrameLayout frame;
	RadioGroup menuBar;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        validate();
    }
    
    @Override
    public void onBackPressed() {
    	try {
			lam.getCurrentActivity().onBackPressed();
		} catch (Exception e) {
//			e.printStackTrace();
			super.onBackPressed();
		}
    }
    
    private void validate()
    {
    	final InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
    	final EditText et = new EditText(this);
    	et.setInputType(InputType.TYPE_CLASS_NUMBER);
    	et.addTextChangedListener(new TextWatcher(){

			@Override
			public void afterTextChanged(Editable s) {
				if (s.toString().equals("030017"))
				{
					imm.hideSoftInputFromWindow(et.getWindowToken(), 0);
					showMain();
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub
				
			}});
    	setContentView(et);
    	
    	Timer timer = new Timer();
		timer.schedule(new TimerTask(){

			@Override
			public void run() {
				imm.showSoftInput(et, 0);
			}}, 100);
    }
    
    private void showMain()
    {
        setContentView(R.layout.main_activity);
		
		lam = getLocalActivityManager();
		
		frame = (FrameLayout) findViewById(R.id.frame);
		menuBar = (RadioGroup) findViewById(R.id.menuBar);
		
		menuBar.setOnCheckedChangeListener(new OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				switch (checkedId) {
				case R.id.words:
					//星座物语
					frame.removeAllViews();
					frame.addView(lam.startActivity("words", new Intent(MainActivity.this, WordsActivity.class)).getDecorView());
					break;
				case R.id.story:
					//故事集锦
					frame.removeAllViews();
					frame.addView(lam.startActivity("story", new Intent(MainActivity.this, StoryActivity.class)).getDecorView());
					break;
				case R.id.joke:
					//笑话精粹
					frame.removeAllViews();
					frame.addView(lam.startActivity("joke", new Intent(MainActivity.this, JokeActivity.class)).getDecorView());
					break;
				case R.id.life:
					//生活百科
					frame.removeAllViews();
					frame.addView(lam.startActivity("life", new Intent(MainActivity.this, LifeActivity.class)).getDecorView());
					break;

				default:
					break;
				}
			}});
    }
}