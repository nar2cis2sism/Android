package com.tower.view;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import engine.game.GameAnimation;
import engine.game.Sprite;

public class Bullet extends Sprite {
	
	private Tower tower;								//每个子弹属于一个炮塔
	
	private Enemy enemy;								//每个子弹攻击一个敌人
	
	private int damage;									//子弹的破坏力
	
	private Bitmap origin;								//原始图片，用于旋转
	
	private boolean isMoving;							//移动开关
	
	private int ox,oy;									//记录子弹原始坐标

	public Bullet(Bitmap image) {
		super(image);
		origin = image;
	}
	
	public void setEnemy(Enemy enemy) {
		(this.enemy = enemy).consumeHP(damage);
		ox = getRefPixelX();
		oy = getRefPixelY();
		isMoving = true;
	}
	
	public void setTower(Tower tower) {
		damage = (this.tower = tower).getAttack();
	}
	
	private void rotateImage(int enemyX, int enemyY)
	{
		//计算子弹和敌人之间的角度，以便旋转图片
		double angle = Math.toDegrees(Math.atan2(enemyY - getRefPixelY(), enemyX - getRefPixelX()));
		setImage(rotate(origin, (float) angle));
	}
	
	/**
	 * 图片旋转
	 * @param angle 旋转角度
	 */
	
	public static Bitmap rotate(Bitmap image, float angle)
	{
		if (angle == 0)
		{
			return image;
		}
		
		Matrix m = new Matrix();
		m.postRotate(angle);
		return getBitmap(image, m);
	}
	
	/**
	 * 通过矩阵变换创建图片
	 * @param image
	 * @param m
	 * @return
	 */
	
	public static Bitmap getBitmap(Bitmap image, Matrix m)
	{
		return Bitmap.createBitmap(image, 0, 0, image.getWidth(), image.getHeight(), m, true);
	}

	/**
	 * 移动子弹，自动追踪敌人
	 */
	
	public void move()
	{
		if (enemy == null)
		{
			throw new NullPointerException("no enemy target");
		}
		
		if (!isMoving)
		{
			return;
		}
		
		//敌人位置
		int enemyX = enemy.centerX();
		int enemyY = enemy.centerY();
		
		int dx = (enemyX - ox) / 3;
		int dy = (enemyY - oy) / 3;
		if (GameAnimation.isOutOfRange(getRefPixelX(), enemyX, dx) 
		||  GameAnimation.isOutOfRange(getRefPixelY(), enemyY, dy))
		{
		    setRefPixelPosition(enemyX, enemyY);
			//击中敌人
			isMoving = false;
		}
		else
		{
			rotateImage(enemyX, enemyY);
			move(dx, dy);
		}
	}
	
	public boolean isMoving()
	{
		return isMoving;
	}
	
	public Enemy getEnemy() {
		return enemy;
	}
	
	public Tower getTower() {
		return tower;
	}
	
	/**
	 * @param mul 伤害加倍
	 */
	
	public void damage(int mul)
	{
		enemy.isAttack(damage, mul);
	}
}